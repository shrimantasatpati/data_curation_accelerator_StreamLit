import re

import datetime


def header_small(uppercase_columns, df):
    """
    The function converts all the column names mentioned in the uppercase_columns list to lowercase.

    Parameters
    ----------
    uppercase_columns : LIST
        List of that columns that needs to be converted to lowercase.

    df : DATAFRAME
        It is the dataframe whose headers needs to be cleaned.

    Returns
    -------
    df : DATAFRAME
        dataframe with the updated lowercase columns.
    """
    for i in uppercase_columns:
        df = df.withColumnRenamed(df.columns[i], df.columns[i].lower())
    return df


def remove_spaces_add_underscore(columns_with_space, df):
    """
    The function removes all the leading and trailing spaces and add underscore between two words.

    Parameters
    ----------
    columns_with_space : LIST
        List of columns that from which spaces needs to be remove and undercore needs to added.

    df : DATAFRAME
        It is the dataframe whose headers needs to be cleaned.

    Returns
    -------
    df : DATAFRAME
        Dataframe with spaces removed and underscores added.
    """
    for i in columns_with_space:
        df = df.withColumnRenamed(df.columns[i], "_".join(df.columns[i].split()))
    return df


def remove_special_characters(special_col, df):
    """
    The function removes all the special characters present in the column names

    Parameters
    ----------
    special_col : LIST
        List of column names containing special characters.

    df : DATAFRAME
        It is the dataframe whose headers needs to be cleaned.

    Returns
    -------
    df : DATAFRAME
        Dataframe with special characters removed.
    """
    for i in special_col:
        new = re.sub("[^a-zA-Z_0-9]", "", df.columns[i])
        df = df.withColumnRenamed(df.columns[i], new)
    return df


def change_header(df, count1=None):
    h_none = []
    dummy = []
    for h, i in enumerate(df.columns):
        if re.match(r"^_c\d{1,4}$", i):
            df = df.withColumnRenamed(i, "unnamed_" + str(h))
            h_none.append(i)
            if not df.filter(col(i).isNotNull()).count() >= 1:
                df = df.drop(i)
                dummy.append(i)
        if i == "":
            df = df.withColumnRenamed(i, "unnamed_{}".format(h))
            h_none.append(i)

    return df, h_none, dummy

def logs(part, message):
    """


    Parameters
    ----------
    message : TYPE
        DESCRIPTION.

    Returns
    -------
    list
        DESCRIPTION.

    """
    now = datetime.datetime.now()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
    return [timestamp, part, message]


def check_key(dic, key):
    """


    Parameters
    ----------
    dic : TYPE
        DESCRIPTION.
    key : TYPE
        DESCRIPTION.

    Returns
    -------
    TYPE
        DESCRIPTION.

    """
    return True if key in dic.keys() else False


def implementation_header_cleansing(header_cleansing, df):
    """


    Parameters
    ----------
    header_cleansing : TYPE
        DESCRIPTION.

    df : DATAFRAME
        It is the dataframe whose headers needs to be cleaned.

    Returns
    -------
    df : DATAFRAME
        DESCRIPTION.
    row : LIST
        DESCRIPTION.

    """
    row = []
    if check_key(header_cleansing, "Have Uppercase"):
        df = header_small(header_cleansing["Have Uppercase"], df)
        row.append(logs("Header", "UpperCase in {} headers are changed to LowerCase ".format([df.columns[i] for i in header_cleansing["Have Uppercase"]])))

    if check_key(header_cleansing, "Have Space"):
        df = remove_spaces_add_underscore(header_cleansing["Have Space"], df)
        row.append(logs("Header","Leading and trailing spaces in {} headers are removed and in between spaces are replaced with underscore".format([df.columns[i] for i in header_cleansing["Have Space"]])))

    if check_key(header_cleansing, "Have Special Characters"):
        df = remove_special_characters(header_cleansing["Have Special Characters"], df)
        row.append(logs("Header", "Special Characters in {} headers are removed  ".format([df.columns[i] for i in header_cleansing["Have Special Characters"]])))

    return df, row