from pyspark.sql.functions import *

import datetime


def trim_leading_trailing_spaces(df, column_names):
    """


    Parameters
    ----------
    df : TYPE
        DESCRIPTION.
    column_names : TYPE
        DESCRIPTION.

    Returns
    -------
    df : TYPE
        DESCRIPTION.

    """
    for i in column_names:
        df = df.withColumn(i, trim(df[i]))
    return df


def missing_values(df, column_names):
    """


    Parameters
    ----------
    df : TYPE
        DESCRIPTION.
    column_names : TYPE
        DESCRIPTION.

    Returns
    -------
    df : TYPE
        DESCRIPTION.

    """
    for i in column_names:
        df = df.withColumn(i, when(col(i).isNull(), None).when(col(i) == '', None).otherwise(col(i)))
    return df


def drop_duplicates(df, primary_key=None, composite_keys=None):
    """


    Parameters
    ----------
    df : TYPE
        DESCRIPTION.
    primary_key : TYPE, optional
        DESCRIPTION. The default is None.

    Returns
    -------
    TYPE
        DESCRIPTION.

    """
    if primary_key != None:
        return df.dropDuplicates([primary_key])
    if composite_keys != None:
        return df.dropDuplicates(composite_keys)
    else:
        return df.distinct()


def remove_special_charecters(columns, df, list2=None, reg_ex=None,valid_across_allcol=None):
    if reg_ex is None:
        reg_ex = r"[^a-zA-Z0-9@\;\:\,\/\\\.\_\ \-]"
        if valid_across_allcol != None:
            for i in valid_across_allcol:
                reg_ex = reg_ex[:-1] + "\{}".format(str(i)) + reg_ex[-1:]
    if list2 is not None:
        for i in list2.keys():
            if i == "@":
                reg_ex1 = reg_ex
            else:
                reg_ex1 = reg_ex[:-2] + r"\{}".format(i) + reg_ex[-2:]
            for j in list2[i]:
                df = df.withColumn(j, regexp_replace(col(j), reg_ex1, ''))
    if len(columns) > 0:
        for i in columns:
            df = df.withColumn(i, regexp_replace(col(i), reg_ex, ''))
    return df


def date_iso(df, date_columns):
    if "string" in date_columns.keys() and len(date_columns["string"]) > 0:
        for i in date_columns["string"]:
            df = df.withColumn(i, when(to_date(col(i), 'd/M/yyyy').isNotNull(), to_date(col(i), 'd/M/yyyy'))
                               .when(to_date(col(i), 'M/d/yyyy').isNotNull(), to_date(col(i), 'M/d/yyyy'))
                               .when(to_date(col(i), 'MM/dd/yyyy').isNotNull(), to_date(col(i), 'MM/dd/yyyy'))
                               .when(to_date(col(i), 'M-d-yyyy').isNotNull(), to_date(col(i), 'M-d-yyyy'))
                               .when(to_date(col(i), 'd-M-yyyy').isNotNull(), to_date(col(i), 'd-M-yyyy'))
                               .when(to_date(col(i), 'dd-MM-yyyy').isNotNull(), to_date(col(i), 'dd-MM-yyyy'))
                               .when(to_date(col(i), 'dd/MM/yyyy').isNotNull(), to_date(col(i), 'dd/MM/yyyy'))
                               .when(to_date(col(i), 'yyyy/MM/dd').isNotNull(), to_date(col(i), 'yyyy/MM/dd'))
                               .when(to_date(col(i), 'yyyy/dd/MM').isNotNull(), to_date(col(i), 'yyyy/dd/MM'))
                               .when(to_date(col(i), 'yyyy-MM-dd').isNotNull(), to_date(col(i), 'yyyy-MM-dd'))
                               .when(to_date(col(i), 'yyyy-dd-MM').isNotNull(), to_date(col(i), 'yyyy-dd-MM'))
                               .otherwise(col(i)))
            df = df.withColumn(i, to_date(col(i)))

    if "datetype" in date_columns.keys() and len(date_columns["datetype"]):
        for i in date_columns["datetype"]:
            df = df.withColumn(i, date_format(col(i), "yyyy-mm-dd"))
            df = df.withColumn(i, to_date(col(i)))
    return df


def remove_l_t_valid_special_characters(list1, df, list2=None, reg_ex=None,valid_across_allcol=None):
    """list 2 is from config """  # {"@":[col_name,col_name]}
    """ list 1 will have column names that contain leading and trailing special chars leaving the list2 columns   """
    if reg_ex is None:
        reg_ex = r"[^a-zA-Z0-9@\;\:\,\/\\\.\_\ \-]"
        if valid_across_allcol != None:
            for i in valid_across_allcol:
                reg_ex = reg_ex[:-1] + "\{}".format(str(i)) + reg_ex[-1:]

    if len(list2) > 0:

        for i in list2:
            for j in list2[i]:
                if j in list1:
                    list1.remove(j)
                df = df.withColumn(j, concat_ws("",
                                                regexp_extract(regexp_extract(col(j), r'^[^\w]*', 0), "\{}".format(i),
                                                               0),
                                                regexp_replace(regexp_replace(col(j), '^[^\w]*|[^\w]*$', ''), reg_ex,
                                                               ""),
                                                regexp_extract(regexp_extract(col(j), r'[^\w]*$', 0), "\{}".format(i),
                                                               0)))

        if len(list1) > 0:
            for i in list1:
                df = df.withColumn(i, regexp_replace(col(i), r'^[^\w]*|[^\w]*$', ''))
        return df
    else:
        for i in list1:
            df = df.withColumn(i, regexp_replace(col(i), r'^[^\w]*|[^\w]*$', ''))
        return df


def to_iso(df, timestamp_columns, inputtz=None, outputtz=None):
    if inputtz is None:
        inputtz = "GMT"
    if outputtz is None:
        outputtz = "UTC"
    output_format = 'yyyy-MM-dd\'T\'HH:mm:ss.SSS\'Z\''
    collist = []
    for i in timestamp_columns.values():
        collist += i
    for colname in collist:
        # Convert the input timestamp to UTC
        utc_time = to_utc_timestamp(col(colname), inputtz)
        # Convert the UTC timestamp to the output format
        iso_time = from_utc_timestamp(utc_time, outputtz).cast('string')
        # Remove any trailing zeros from the seconds
        iso_time = regexp_replace(iso_time, '\.0*Z$', 'Z')
        # Add the new column to the DataFrame
        df = df.withColumn(colname, to_timestamp(date_format(iso_time, output_format)))
        df = df.withColumn(colname, to_timestamp(colname))
    return df


def check_key(dic, key):
    """


    Parameters
    ----------
    dic : TYPE
        DESCRIPTION.
    key : TYPE
        DESCRIPTION.

    Returns
    -------
    TYPE
        DESCRIPTION.

    """
    return True if key in dic.keys() else False


def logs(part, message):
    """


    Parameters
    ----------
    message : TYPE
        DESCRIPTION.

    Returns
    -------
    list
        DESCRIPTION.

    """
    now = datetime.datetime.now()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
    return [timestamp, part, message]
