from pyspark.sql.functions import *
from pyspark.sql.types import *


def check_null_values(df):
    """


    Parameters
    ----------
    df : TYPE
        DESCRIPTION.

    Returns
    -------
    l : TYPE
        DESCRIPTION.

    """

    l = []
    for i in df.columns:
        if df.filter(col(i) == "").count() > 0:
            l.append(i)

    return l


def date_col_string(df):
    date_columns = {}
    df1=df.limit(1000)
    for col_name, data_type in df.dtypes:
        if data_type == 'date' or isinstance(data_type, DateType):
            if "datetype" not in date_columns.keys():
                date_columns["datetype"]=[]
            date_columns["datetype"].append(col_name)
            continue
        else:
            df1 = df1.withColumn("date check1", regexp_replace(col(col_name), r"[^0-9\/\-]", ""))
            df1 = df1.withColumn("date check2", col("date check1").rlike(
                r"^\d{4}[/-]\d{1,2}[/-]\d{1,2}$|^\d{1,2}[/-]\d{1,2}[/-]\d{4}$|^\d{1,2}[/-]\d{4}[/-]\d{1,2}$"))
            if df1.filter(col("date check2") == True).count() > 0:
                if "string" not in date_columns.keys():
                    date_columns["string"]=[]
                date_columns["string"].append(col_name)
                df = df.withColumn(col_name, regexp_replace(col(col_name), r"[^0-9\/\-]", ""))
    df1 = df1.drop("date check1", "date check2")
    return df, date_columns


def check_timestamp(df):
    timestamp_columns = {}
    df1=df.limit(1000)
    for col_name, data_type in df.dtypes:

        if data_type == 'timestamp' or isinstance(data_type, TimestampType):
            if "timestamp" not in timestamp_columns.keys():
                timestamp_columns['timestamp']=[]
            timestamp_columns['timestamp'].append(col_name)
            continue
        df1 = df1.withColumn("datetime check1", regexp_replace(col(col_name), r"[^0-9+TZ:./ -]", ""))
        df1 = df1.withColumn("datetime check2", col("datetime check1").rlike(
            r"\d{4}[/-]\d{2}[-/]\d{2}[T ]\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}[:]\d{2}|)"))
        if df1.filter(col("datetime check2") == True).count() > 0:
            if "string" not in timestamp_columns.keys():
                timestamp_columns["string"]=[]
            timestamp_columns["string"].append(col_name)
            df = df.withColumn(col_name, regexp_replace(col(col_name), r"[^0-9+TZ:./ -]", ""))
        df1 = df1.drop("datetime check2", "datetime check1")
    return df, timestamp_columns


def check_date(df, columnlist):
    if len(columnlist) >0:
        for i in columnlist.keys():
            for column in columnlist[i]:
                # iso_pattern = r'^\d{4}-\d{2}-\d{2}$'
                is_iso = to_date(col(column).cast('string'), "yyyy-MM-dd").isNotNull()
                # Add the new column to the DataFrame
                df = df.withColumn(column + '_is_iso', when(col(column)!=None, to_date(col(column).cast('string'), "yyyy-MM-dd").isNotNull()).otherwise(True))
                if df.filter(col(column + '_is_iso') == False).count() > 0 or i == "string":
                    df = df.drop(column + '_is_iso')
                else:
                    columnlist[i].remove(column)
                    df = df.drop(column + '_is_iso')
        return columnlist
    else:
        return columnlist


def check_time(df, columnlist):
    """


    Parameters
    ----------
    df : TYPE
        DESCRIPTION.
    columnlist : TYPE
        DESCRIPTION.

    Returns
    -------
    l : TYPE
        DESCRIPTION.

    """
    if len(columnlist) >0:
        for i in columnlist.keys():
            for column in columnlist[i]:
                iso_pattern = r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2}|)'
                is_iso = regexp_extract(col(column).cast('string'), iso_pattern, 0).isNotNull()
                # Add the new column to the DataFrame
                df = df.withColumn(column + '_is_iso', when(col(column)!= None, regexp_extract(col(column).cast('string'), iso_pattern, 0).isNotNull()).otherwise(True))
                if df.filter(col(column + '_is_iso') == False).count() > 0 or i == "string":
                    df = df.drop(column + '_is_iso')
                else:
                    columnlist[i].remove(column)
                    df = df.drop(column + '_is_iso')
        return columnlist
    else:
        return columnlist


def check_duplicates(df, primary_key=None, composite_keys=None,count1=None):
    """


    Parameters
    ----------
    df : TYPE
        DESCRIPTION.
    primary_key : TYPE, optional
        DESCRIPTION. The default is None.

    Returns
    -------
    bool
        DESCRIPTION.

    """
    if count1 is None:
        count1=df.count()
    if primary_key is not None:
        count2=df.dropDuplicates([primary_key]).count()
        if count1 >count2 :
            return True
        else:
            return False
    elif composite_keys is not None:
        count2=df.dropDuplicates(composite_keys).count()
        if count1 >count2:
            return True
        else:
            return False
    else:
        count2=df.distinct().count()
        if count1 >count2 :
            return True
        else:
            return False


def check_leading_trailing_spaces(df):
    """


    Parameters
    ----------
    df : TYPE
        DESCRIPTION.

    Returns
    -------
    l : TYPE
        DESCRIPTION.

    """
    l = []
    for i in df.columns:
        df = df.withColumn("hasspace", regexp_extract(col(i), r'^\s+|\s+$', 0).rlike(r'^\s+|\s+$'))
        if df.filter(col("hasspace") == True).count() > 0:
            l.append(i)
    df = df.drop("hasspace")
    return l


def check_special_char(df, valid_across_allcol=None,date_columns=None, timestamp_columns=None, list2=None):
    """


    Parameters
    ----------
    valid_across_allcol
    timestamp_columns
    df : TYPE
        DESCRIPTION.

    Returns
    -------
    l : TYPE
        DESCRIPTION.

    """
    columns = df.columns
    vs = {}
    l = []
    reg_ex = r"[^a-zA-Z0-9@\;\:\,\/\\\.\_\ \-]"
    if valid_across_allcol != None:
        for i in valid_across_allcol:
            reg_ex = reg_ex[:-1] + "\{}".format(str(i)) + reg_ex[-1:]
    if "string" in date_columns.keys():
        for i in date_columns["string"]:
            columns.remove(i)
    if "string" in timestamp_columns.keys():
        for i in timestamp_columns["string"]:
            columns.remove(i)
    if list2 is not None:
        for i in list2.keys():
            for j in list2[i]:
                if i not in vs.keys():
                    vs[i] = []
                reg_ex1 = reg_ex[:-1] + "\{}".format(str(i)) + reg_ex[-1:]
                if df.where(col(j).rlike(reg_ex1)).count() > 0:
                    vs[i].append(j)
                columns.remove(j)

    for i in columns:
        if df.where(col(i).rlike(reg_ex)==True).count() > 0:
            l.append(i)
    return l,vs, reg_ex


def check_l_t_special_valid_chars(df, list2=None,date_columns=None,timestamp_columns=None):
    """


    Parameters
    ----------
    df : TYPE
        DESCRIPTION.

    Returns
    -------
    l : TYPE
        DESCRIPTION.

    """
    l=[]
    f = df.columns
    if "string" in date_columns.keys():
        for i in date_columns["string"]:
            f.remove(i)
    if "string" in timestamp_columns.keys():
        for i in timestamp_columns["string"]:
            f.remove(i)
    if list2 is not None:
        for i in list2.keys():
            reg_ex = r"^(\{})?\b\w.*\w\b(\{})?$".format(i,i)
            for j in list2[i]:
                if df.where(col(j).rlike(reg_ex) == False).count() > 0:
                    l.append(j)
                    continue
                else:
                    f.remove(j)
                    list2[i].remove(j)
    for i in f:
        if i in l:
            continue
        df = df.withColumn("has_spl_char", regexp_extract(col(i), r"^[^\w]+|[^\w]+$", 0).rlike(r"^[^\w]+|[^\w]+$"))
        if df.filter(col("has_spl_char") == True).count() > 0:
            continue
        else:
            f.remove(i)

    df = df.drop("has_spl_char")
    return f


def not_valid_primarykey_compositekey(df, primary_key=None, composite_keys=None):
    """


    Parameters
    ----------
    df : TYPE
        DESCRIPTION.
    primary_key : TYPE, optional
        DESCRIPTION. The default is None.

    Returns
    -------
    bool
        DESCRIPTION.

    """
    output = {}
    if composite_keys != None:
        df = df.withColumn("composite_key",
                           concat_ws("", *[coalesce(col(c).cast(StringType()), lit("")) for c in composite_keys]))
        if df.filter(col("composite_key") == "").count() > 0:
            output["Valid Composite key"] = "not valid as they have atleast 1 null value in combination"

        else:
            output["Valid Composite key"] = "valid as they don't have any null value in combination"
    else:
        output["Valid Composite key"] = "not passed/given"
    if primary_key != None:
        if df.filter(col(primary_key).isNull()).count() > 0:
            output["Valid Primary key"] = "not valid as it does have atleast 1 null value"
        else:
            output["Valid Primary key"] = "valid as it doesn't have any null value"
    else:
        output["Valid Primary key"] = "not passed/given"
    return output
