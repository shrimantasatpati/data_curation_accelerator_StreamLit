import re





def check_uppercase(df):
    """
    The function checks if any of the column names are in uppercase,
    and returns the names of the columns which are in uppercase.

    Parameters
    ----------
    df : DATAFRAME
        It is the dataframe whose headers needs to be checked.

    Returns
    -------
    uppercase : LIST
        List of column names that are uppercase.
    """
    uppercase = [i for i in range(len(df.columns)) if df.columns[i] != df.columns[i].lower()]
    return uppercase


def check_space(df):
    """
    The function checks if any of the column names has spaces,
    and returns the names of the columns which has spaces.

    Parameters
    ----------
    df : DATAFRAME
        It is the dataframe whose headers needs to be checked.

    Returns
    -------
    columns_with_space : LIST
        List of column names that has spaces.
    """
    columns_with_space = [i for i in range(len(df.columns)) if df.columns[i] != "".join(df.columns[i].split())]
    return columns_with_space


def check_for_special_characters(df):
    """
    The function checks if any of the column names has special characters,
    and returns the names of the columns which has special characters.

    Parameters
    ----------
    df : DATAFRAME
        It is the dataframe whose headers needs to be checked.

    Returns
    -------
    special_col : LIST
        List of column names that has special characters.
    """
    special_col = [i for i in range(len(df.columns)) if re.search(r"[^a-zA-z_ 0-9]", df.columns[i])]
    return special_col


def implement_header_validation(df):
    """
    The function implements the following header validation checks:
        1. Uppercase Check
        2. Has Spaces Check
        3. Special Characters Check

    Parameters
    ----------
    df : DATAFRAME
        It is the dataframe whose headers needs to be checked.

    Returns
    -------
    output : DICTIONARY
        Dictionary of all the cleaning that needs to be done.
    """
    output = {}

    uppercase_columns = check_uppercase(df)
    if len(uppercase_columns) > 0:
        output["Have Uppercase"] = uppercase_columns

    columns_with_space = check_space(df)
    if len(columns_with_space) > 0:
        output["Have Space"] = columns_with_space

    special_columns = check_for_special_characters(df)
    if len(special_columns) > 0:
        output["Have Special Characters"] = special_columns
    return output