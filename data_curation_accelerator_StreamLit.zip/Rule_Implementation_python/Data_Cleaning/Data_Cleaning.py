import pandas as pd
import re
from datetime import datetime, timezone
import pytz

def trim_leading_trailing_spaces(df, column_names):
    for column in column_names:
        df[column] = df[column].str.strip()
    return df

def missing_values(df, column_names):
    for column in column_names:
        df[column] = df[column].replace(['', None], pd.NA)
    return df

def drop_duplicates(df, primary_key=None, composite_keys=None):
    if primary_key is not None:
        return df.drop_duplicates(subset=[primary_key])
    if composite_keys is not None:
        return df.drop_duplicates(subset=composite_keys)
    else:
        return df.drop_duplicates()

def remove_special_characters(columns, df, list2=None, reg_ex=None, valid_across_allcol=None):
    if reg_ex is None:
        reg_ex = r"[^a-zA-Z0-9@:,/\._\-]"
        if valid_across_allcol is not None:
            for char in valid_across_allcol:
                reg_ex = reg_ex[:-1] + re.escape(str(char)) + reg_ex[-1:]
    
    if list2 is not None:
        for char, cols in list2.items():
            if char == "@":
                reg_ex1 = reg_ex
            else:
                reg_ex1 = reg_ex[:-1] + re.escape(char) + reg_ex[-1:]
            for col in cols:
                df[col] = df[col].str.replace(reg_ex1, '', regex=True)
    
    for col in columns:
        df[col] = df[col].str.replace(reg_ex, '', regex=True)
    
    return df

def date_iso(df, date_columns):
    date_formats = ['%d/%m/%Y', '%m/%d/%Y', '%d-%m-%Y', '%m-%d-%Y', '%Y/%m/%d', '%Y/%d/%m', '%Y-%m-%d', '%Y-%d-%m']
    
    if "string" in date_columns and date_columns["string"]:
        for col in date_columns["string"]:
            df[col] = pd.to_datetime(df[col], format='mixed', errors='coerce')
    
    if "datetype" in date_columns and date_columns["datetype"]:
        for col in date_columns["datetype"]:
            df[col] = pd.to_datetime(df[col]).dt.strftime('%Y-%m-%d')
            df[col] = pd.to_datetime(df[col])
    
    return df

def remove_l_t_valid_special_characters(list1, df, list2=None, reg_ex=None, valid_across_allcol=None):
    if reg_ex is None:
        reg_ex = r"[^a-zA-Z0-9@:,/\._\-]"
        if valid_across_allcol is not None:
            for char in valid_across_allcol:
                reg_ex = reg_ex[:-1] + re.escape(str(char)) + reg_ex[-1:]

    if list2:
        for char, cols in list2.items():
            for col in cols:
                if col in list1:
                    list1.remove(col)
                df[col] = df[col].apply(lambda x: re.sub(f'^[^\\w]*({re.escape(char)})', r'\1', x))
                df[col] = df[col].apply(lambda x: re.sub(f'[^\\w]*({re.escape(char)})$', r'\1', x))
                df[col] = df[col].str.replace(reg_ex, '', regex=True)

    for col in list1:
        df[col] = df[col].str.replace(r'^[^\w]*|[^\w]*$', '', regex=True)

    return df

def to_iso(df, timestamp_columns, inputtz=None, outputtz=None):
    if inputtz is None:
        inputtz = "GMT"
    if outputtz is None:
        outputtz = "UTC"
    
    input_tz = pytz.timezone(inputtz)
    output_tz = pytz.timezone(outputtz)
    
    for col_type, cols in timestamp_columns.items():
        for col in cols:
            df[col] = pd.to_datetime(df[col], utc=True)
            df[col] = df[col].dt.tz_convert(output_tz).dt.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
            df[col] = df[col].apply(lambda x: re.sub(r'\.0*Z$', 'Z', x))
            df[col] = pd.to_datetime(df[col], format='%Y-%m-%dT%H:%M:%S.%fZ')
    
    return df

def check_key(dic, key):
    return key in dic

def logs(part, message):
    now = datetime.now()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
    return [timestamp, part, message]