import re
import datetime
import pandas as pd

def header_small(uppercase_columns, df):
    """
    The function converts all the column names mentioned in the uppercase_columns list to lowercase.

    Parameters
    ----------
    uppercase_columns : LIST
        List of column indices that need to be converted to lowercase.

    df : DataFrame
        It is the dataframe whose headers need to be cleaned.

    Returns
    -------
    df : DataFrame
        dataframe with the updated lowercase columns.
    """
    df.columns = [col.lower() if i in uppercase_columns else col for i, col in enumerate(df.columns)]
    return df

def remove_spaces_add_underscore(columns_with_space, df):
    """
    The function removes all the leading and trailing spaces and adds underscore between two words.

    Parameters
    ----------
    columns_with_space : LIST
        List of column indices from which spaces need to be removed and underscores need to be added.

    df : DataFrame
        It is the dataframe whose headers need to be cleaned.

    Returns
    -------
    df : DataFrame
        Dataframe with spaces removed and underscores added.
    """
    df.columns = ['_'.join(df.columns[i].split()) if i in columns_with_space else col for i, col in enumerate(df.columns)]
    return df

def remove_special_characters(special_col, df):
    """
    The function removes all the special characters present in the column names

    Parameters
    ----------
    special_col : LIST
        List of column indices containing special characters.

    df : DataFrame
        It is the dataframe whose headers need to be cleaned.

    Returns
    -------
    df : DataFrame
        Dataframe with special characters removed.
    """
    df.columns = [re.sub("[^a-zA-Z_0-9]", "", col) if i in special_col else col for i, col in enumerate(df.columns)]
    return df

def change_header(df, count1=None):
    h_none = []
    dummy = []
    new_columns = []

    for h, col in enumerate(df.columns):
        if re.match(r"^_c\d{1,4}$", col):
            new_col = f"unnamed_{h}"
            h_none.append(col)
            if df[col].isnull().all():
                dummy.append(col)
                df = df.drop(columns=[col])
            else:
                new_columns.append(new_col)
        elif col == "":
            new_col = f"unnamed_{h}"
            h_none.append(col)
            new_columns.append(new_col)
        else:
            new_columns.append(col)

    df.columns = new_columns
    return df, h_none, dummy

def logs(part, message):
    """
    Parameters
    ----------
    message : str
        The log message.

    Returns
    -------
    list
        A list containing timestamp, part, and message.
    """
    now = datetime.datetime.now()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
    return [timestamp, part, message]

def check_key(dic, key):
    """
    Parameters
    ----------
    dic : dict
        The dictionary to check.
    key : str
        The key to look for.

    Returns
    -------
    bool
        True if the key is in the dictionary, False otherwise.
    """
    return key in dic

def implementation_header_cleansing(header_cleansing, df):
    """
    Parameters
    ----------
    header_cleansing : dict
        Dictionary containing information about headers to be cleaned.

    df : DataFrame
        It is the dataframe whose headers need to be cleaned.

    Returns
    -------
    df : DataFrame
        Cleaned dataframe.
    row : LIST
        List of log messages.
    """
    row = []
    if check_key(header_cleansing, "Have Uppercase"):
        df = header_small(header_cleansing["Have Uppercase"], df)
        row.append(logs("Header", f"UpperCase in {[df.columns[i] for i in header_cleansing['Have Uppercase']]} headers are changed to LowerCase"))

    if check_key(header_cleansing, "Have Space"):
        df = remove_spaces_add_underscore(header_cleansing["Have Space"], df)
        row.append(logs("Header", f"Leading and trailing spaces in {[df.columns[i] for i in header_cleansing['Have Space']]} headers are removed and in between spaces are replaced with underscore"))

    if check_key(header_cleansing, "Have Special Characters"):
        df = remove_special_characters(header_cleansing["Have Special Characters"], df)
        row.append(logs("Header", f"Special Characters in {[df.columns[i] for i in header_cleansing['Have Special Characters']]} headers are removed"))

    return df, row