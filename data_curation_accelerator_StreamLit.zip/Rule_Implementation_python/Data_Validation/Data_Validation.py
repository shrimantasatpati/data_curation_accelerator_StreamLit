import pandas as pd
import numpy as np
import re
from datetime import datetime

def check_null_values(df):
    return [col for col in df.columns if df[col].eq('').any()]

def date_col_string(df):
    date_columns = {"datetype": [], "string": []}
    df1 = df.head(1000)
    
    for col_name in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col_name]):
            date_columns["datetype"].append(col_name)
        else:
            df1[f"{col_name}_date_check1"] = df1[col_name].astype(str).str.replace(r"[^0-9/\-]", "", regex=True)
            df1[f"{col_name}_date_check2"] = df1[f"{col_name}_date_check1"].str.match(
                r"^\d{4}[/-]\d{1,2}[/-]\d{1,2}$|^\d{1,2}[/-]\d{1,2}[/-]\d{4}$|^\d{1,2}[/-]\d{4}[/-]\d{1,2}$"
            )
            if df1[f"{col_name}_date_check2"].any():
                date_columns["string"].append(col_name)
                df[col_name] = df[col_name].astype(str).str.replace(r"[^0-9/\-]", "", regex=True)
    
    return df, date_columns

def check_timestamp(df):
    timestamp_columns = {"timestamp": [], "string": []}
    df1 = df.head(1000)
    
    for col_name in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col_name]):
            timestamp_columns["timestamp"].append(col_name)
        else:
            df1[f"{col_name}_datetime_check1"] = df1[col_name].astype(str).str.replace(r"[^0-9+TZ:./ -]", "", regex=True)
            df1[f"{col_name}_datetime_check2"] = df1[f"{col_name}_datetime_check1"].str.match(
                r"\d{4}[/-]\d{2}[-/]\d{2}[T ]\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}[:]\d{2}|)"
            )
            if df1[f"{col_name}_datetime_check2"].any():
                timestamp_columns["string"].append(col_name)
                df[col_name] = df[col_name].astype(str).str.replace(r"[^0-9+TZ:./ -]", "", regex=True)
    
    return df, timestamp_columns

def check_date(df, columnlist):
    for col_type, columns in columnlist.items():
        for column in columns[:]:
            if col_type == "string":
                continue
            is_iso = pd.to_datetime(df[column].astype(str), format='%Y-%m-%d', errors='coerce').notna()
            if not is_iso.all() or col_type == "string":
                continue
            columnlist[col_type].remove(column)
    return columnlist

def check_time(df, columnlist):
    iso_pattern = r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2}|)'
    for col_type, columns in columnlist.items():
        for column in columns[:]:
            if col_type == "string":
                continue
            is_iso = df[column].astype(str).str.match(iso_pattern)
            if not is_iso.all() or col_type == "string":
                continue
            columnlist[col_type].remove(column)
    return columnlist

def check_duplicates(df, primary_key=None, composite_keys=None, count1=None):
    if count1 is None:
        count1 = len(df)
    
    if primary_key is not None:
        count2 = df.drop_duplicates(subset=[primary_key]).shape[0]
    elif composite_keys is not None:
        count2 = df.drop_duplicates(subset=composite_keys).shape[0]
    else:
        count2 = df.drop_duplicates().shape[0]
    
    return count1 > count2

def check_leading_trailing_spaces(df):
    return [col for col in df.columns if df[col].astype(str).str.match(r'^\s+|\s+$').any()]

def check_special_char(df, valid_across_allcol=None, date_columns=None, timestamp_columns=None, list2=None):
    columns = df.columns.tolist()
    vs = {}
    l = []
    reg_ex = r"[^a-zA-Z0-9@:,/\._\-]"
    
    if valid_across_allcol:
        reg_ex = reg_ex[:-1] + ''.join(re.escape(char) for char in valid_across_allcol) + reg_ex[-1]
    
    for col_type in ['string']:
        if col_type in date_columns:
            columns = [col for col in columns if col not in date_columns[col_type]]
        if col_type in timestamp_columns:
            columns = [col for col in columns if col not in timestamp_columns[col_type]]
    
    if list2:
        for char, cols in list2.items():
            vs[char] = []
            reg_ex1 = reg_ex[:-1] + re.escape(char) + reg_ex[-1]
            for col in cols:
                if df[col].astype(str).str.contains(reg_ex1, regex=True).any():
                    vs[char].append(col)
                columns.remove(col)
    
    l = [col for col in columns if df[col].astype(str).str.contains(reg_ex, regex=True).any()]
    
    return l, vs, reg_ex

def check_l_t_special_valid_chars(df, list2=None, date_columns=None, timestamp_columns=None):
    l = []
    f = df.columns.tolist()
    
    for col_type in ['string']:
        if col_type in date_columns:
            f = [col for col in f if col not in date_columns[col_type]]
        if col_type in timestamp_columns:
            f = [col for col in f if col not in timestamp_columns[col_type]]
    
    if list2:
        for char, cols in list2.items():
            reg_ex = rf"^({re.escape(char)})?\b\w.*\w\b({re.escape(char)})?$"
            for col in cols[:]:
                if not df[col].astype(str).str.match(reg_ex).all():
                    l.append(col)
                else:
                    f.remove(col)
                    cols.remove(col)
    
    for col in f[:]:
        if col in l:
            continue
        if not df[col].astype(str).str.match(r"^[^\w]+|[^\w]+$").any():
            f.remove(col)
    
    return f

def not_valid_primarykey_compositekey(df, primary_key=None, composite_keys=None):
    output = {}
    
    if composite_keys:
        df['composite_key'] = df[composite_keys].astype(str).agg(''.join, axis=1)
        if df['composite_key'].eq('').any():
            output["Valid Composite key"] = "not valid as they have at least 1 null value in combination"
        else:
            output["Valid Composite key"] = "valid as they don't have any null value in combination"
        df = df.drop(columns=['composite_key'])
    else:
        output["Valid Composite key"] = "not passed/given"
    
    if primary_key:
        if df[primary_key].isnull().any():
            output["Valid Primary key"] = "not valid as it does have at least 1 null value"
        else:
            output["Valid Primary key"] = "valid as it doesn't have any null value"
    else:
        output["Valid Primary key"] = "not passed/given"
    
    return output