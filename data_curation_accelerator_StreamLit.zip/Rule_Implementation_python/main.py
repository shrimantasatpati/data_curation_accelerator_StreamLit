import os
import re
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from Rule_Implementation.Data_Cleaning.Data_Cleaning import *
from Rule_Implementation.Data_Validation.Data_Validation import *
from Rule_Implementation.Header_Cleaning.Header_Cleaning import *
from Rule_Implementation.Header_Validation.Header_Validation import *
from pyspark.sql import SparkSession
from pyspark.sql.functions import *


def curate_data(path, logging_path=None, output_file_path=None, primary_key=None, composite_keys=None,
                valid_across_allcol=None, valid_spl_chars=None, inputtz=None, outputtz=None):
    """


    Parameters
    ----------
    path : TYPE
        DESCRIPTION. Path to file
    logging_path : TYPE Optional
        DESCRIPTION. The default is None.
    output_file_path: TYPE optional
        DESCRIPTION. The default is None.
    primary_key : TYPE:string, optional
        DESCRIPTION. The default is None.
    composite_keys: TYPE: list, optional
        DESCRIPTION. The default is None.
    valid_spl_chars : TYPE: Dictionary, optional
        DESCRIPTION. Valid or InValid special characters in the leading and trailing of string across mentioned columns .The default is None.
    valid_across_allcol : TYPE:list, optional
        DESCRIPTION. InValid special characters in the middle of string across all columns .The default is None.
    inputtz : TYPE:string, optional
        DESCRIPTION. input timezone used to correctly convert to output time zone .The default is None.

    outputtz : TYPE:string, optional
        DESCRIPTION. output timezone used to convert to required time zone .The default is None.


    Raises
    ------
    ValueError
        DESCRIPTION. File Not found /File is empty/has only Headers

    Returns
    -------
    df : TYPE
        DESCRIPTION. Dataframe
    rows : TYPE
        DESCRIPTION. logs

    """

    spark = SparkSession.builder.appName("Read CSV").getOrCreate()
    try:
        if path is None:
            raise ValueError("No path given.")
        df = spark.read.format("csv").option("header", True).load(path)
        if df.rdd.isEmpty():
            raise ValueError("File is empty")
        count1 = df.count()
        if df.columns and count1 == 0:
            raise ValueError("DataFrame has only column names and no data.")
    except FileNotFoundError:
        raise ValueError("File/File path Not Found")
    except ValueError as e:
        print(e)
        exit()
    try:
        if all(header == "" for header in df.columns):
            raise Exception("All headers are null.")
    except Exception as e:
        print(e)
        exit()
    for i, column_name in enumerate(df.columns):
        if primary_key is not None:
            if primary_key == column_name:
                primary_key = i
        if composite_keys is not None and column_name in composite_keys:
            composite_keys[composite_keys.index(column_name)] = i
        if valid_spl_chars is not None:
            for j in valid_spl_chars.keys():
                if column_name in valid_spl_chars[j]:
                    valid_spl_chars[j][valid_spl_chars[j].index(column_name)] = i


    header_cleansing_columns = implement_header_validation(df)

    if len(header_cleansing_columns) > 0:
        df, row = implementation_header_cleansing(header_cleansing_columns, df)


    else:
        print("There is no Header cleansing Required")
        now = datetime.datetime.now()
        ts = now.strftime("%Y-%m-%d %H:%M:%S")
        row = [[ts, "Header", "There is no Header cleansing Required"]]
    df, h_none, dummy = change_header(df, count1)
    if h_none is not None:
        now = datetime.datetime.now()
        ts = now.strftime("%Y-%m-%d %H:%M:%S")
        row.append([ts, "Header",
                    "Null header names of indices {} are changed to appropriate name(unnamed_index)".format(h_none)])
    if dummy is not None:
        now = datetime.datetime.now()
        ts = now.strftime("%Y-%m-%d %H:%M:%S")
        row.append([ts, "Header",
                    "Headers that are null & data of that column is entirely null are in  indices {} are deleted".format(
                        dummy)])
    for i, column in enumerate(df.columns):
        if primary_key is not None and primary_key == i:
            primary_key = column
        if composite_keys is not None and i in composite_keys:
            composite_keys[composite_keys.index(i)] = column
        if valid_spl_chars is not None:
            for j in valid_spl_chars.keys():
                if i in valid_spl_chars[j]:
                    valid_spl_chars[j][valid_spl_chars[j].index(i)] = column
    rows = []

    df, date_columns = date_col_string(df)
    df, timestamp_columns = check_timestamp(df)

    space_col = check_leading_trailing_spaces(df)
    if len(space_col) > 0:
        df = trim_leading_trailing_spaces(df, space_col)
        rows.append(logs("Data", "Leading and trailing spaces in {} columns are removed".format(space_col)))

    spl_char_col,v_s, reg_ex = check_special_char(df, valid_across_allcol,date_columns, timestamp_columns, valid_spl_chars)
    if len(spl_char_col) > 0 or len(v_s) > 0:
        df = remove_special_charecters(spl_char_col, df, v_s, reg_ex)
        for i in v_s.keys():
            spl_char_col += v_s[i]
        rows.append(logs("Data", "In valid Special_characters in {} columns are removed".format(spl_char_col)))
    spl_v_char_col = check_l_t_special_valid_chars(df, valid_spl_chars,date_columns,timestamp_columns)
    if len(spl_v_char_col) > 0:
        df = remove_l_t_valid_special_characters(spl_v_char_col,df,valid_spl_chars,reg_ex,valid_across_allcol)
        rows.append(logs("Data",
                         "Leading and trailing invalid special characters in {} columns are removed and the key(special Character) of dictionary is kept in the leading and trailing according to the {} ".format(
                             spl_v_char_col, valid_spl_chars)))

    null_col = check_null_values(df)
    if len(null_col) > 0:
        df = missing_values(df, null_col)
        rows.append(logs("Data", "Missing values in {} columns are replaced with null".format(null_col)))

    if len(date_columns) > 0:
        change_date = check_date(df, date_columns)
        if len(change_date["string"]) > 0 or len(change_date["datetype"]) > 0:
            df = date_iso(df, change_date)
            rows.append(logs("Data", "Date format in {} columns are changed to iso format".format(change_date)))

    if len(timestamp_columns) > 0:
        change_datetime = check_time(df, timestamp_columns)
        if len(change_datetime["string"]) > 0 or len(change_datetime["timestamp"]) > 0:
            df = to_iso(df, change_datetime, inputtz, outputtz)
            rows.append(
                logs("Data", "Date Time format in {} columns are changed to iso format".format(change_datetime)))

    output = not_valid_primarykey_compositekey(df, primary_key, composite_keys)
    rows.append(logs("Data", "Primary Key is {}".format(output["Valid Primary key"])))
    rows.append(logs("Data", "Composite Key is {}".format(output["Valid Composite key"])))
    if check_duplicates(df, primary_key, composite_keys, count1):
        df = drop_duplicates(df, primary_key, composite_keys)
        count = count1 - df.count()
        rows.append(logs('Data', '{} Duplicates are removed'.format(count)))
    if len(rows) == 0:
        print("There is no Data cleansing Required")
        now = datetime.datetime.now()
        ts = now.strftime("%Y-%m-%d %H:%M:%S")
        rows = [[ts, 'Data', 'There is no Data cleansing Required']]
    rows = row + rows
    now = datetime.datetime.now()
    ts = now.strftime("%Y/%m/%d/%H/%M_%S")
    d = spark.createDataFrame(rows, ["Timestamp", "Cleansing Part", "Message"])
    if logging_path is None:
        if output_file_path is None:
            return df, d
        file_name = os.path.basename(path)
        df.write.parquet(output_file_path + f"output/{ts}" + file_name[:-4])
        return d
    else:
        file_name = os.path.basename(path)
        output_file = f"logfile/{ts}_{file_name[:-4]}"
        d.coalesce(1).write.option("header", True).csv(logging_path + output_file)
        if output_file_path is None:
            return df
        file_name = os.path.basename(path)
        df.write.option("header", "true").mode("overwrite").parquet(output_file_path + f"output/{ts}" + file_name[:-4])


if __name__ == "__main__":
    processed_data, logs = curate_data("https://gist.github.com/kevin336/acbb2271e66c10a5b73aacf82ca82784#file-employees-csv", logging_path=None, output_file_path=None, primary_key=None,
                                       composite_keys=None, valid_across_allcol=None, valid_spl_chars=None,
                                       inputtz=None, outputtz=None)
