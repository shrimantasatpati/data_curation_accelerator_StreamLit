import re
import pandas as pd

def check_uppercase(df):
    """
    The function checks if any of the column names are in uppercase,
    and returns the indices of the columns which are in uppercase.

    Parameters
    ----------
    df : pandas.DataFrame
        It is the dataframe whose headers needs to be checked.

    Returns
    -------
    uppercase : LIST
        List of column indices that are uppercase.
    """
    uppercase = [i for i, col in enumerate(df.columns) if col != col.lower()]
    return uppercase

def check_space(df):
    """
    The function checks if any of the column names has spaces,
    and returns the indices of the columns which have spaces.

    Parameters
    ----------
    df : pandas.DataFrame
        It is the dataframe whose headers needs to be checked.

    Returns
    -------
    columns_with_space : LIST
        List of column indices that have spaces.
    """
    columns_with_space = [i for i, col in enumerate(df.columns) if col != "".join(col.split())]
    return columns_with_space

def check_for_special_characters(df):
    """
    The function checks if any of the column names has special characters,
    and returns the indices of the columns which have special characters.

    Parameters
    ----------
    df : pandas.DataFrame
        It is the dataframe whose headers needs to be checked.

    Returns
    -------
    special_col : LIST
        List of column indices that have special characters.
    """
    special_col = [i for i, col in enumerate(df.columns) if re.search(r"[^a-zA-Z_ 0-9]", col)]
    return special_col

def implement_header_validation(df):
    """
    The function implements the following header validation checks:
        1. Uppercase Check
        2. Has Spaces Check
        3. Special Characters Check

    Parameters
    ----------
    df : pandas.DataFrame
        It is the dataframe whose headers needs to be checked.

    Returns
    -------
    output : DICTIONARY
        Dictionary of all the cleaning that needs to be done.
    """
    output = {}

    uppercase_columns = check_uppercase(df)
    if len(uppercase_columns) > 0:
        output["Have Uppercase"] = uppercase_columns

    columns_with_space = check_space(df)
    if len(columns_with_space) > 0:
        output["Have Space"] = columns_with_space

    special_columns = check_for_special_characters(df)
    if len(special_columns) > 0:
        output["Have Special Characters"] = special_columns

    return output